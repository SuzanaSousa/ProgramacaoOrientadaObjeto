﻿// Método Main() ;
using AbstrataCliente;

//Cliente c = new Cliente(1,"suzana"); Não e possivel estanciar objeto da classe abtrata

ClienteFisico cf = new ClienteFisico(2,"Caio", 3333);
cf.Mostrar();