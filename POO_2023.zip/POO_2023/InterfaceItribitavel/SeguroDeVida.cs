using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterfaceItribitavel
{
    public class SeguroDeVida
    {
        public double Valor { get; set; }
         
    }
   
}

