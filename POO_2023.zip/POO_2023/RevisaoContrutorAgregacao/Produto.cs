using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevisaoContrutorAgregacao
{
    public class Produto
    {
        public  static int Codigo { get; set; } //  classe ter acesso ao atributo tendo  modo reduzido
        
        //this
        public string NomeProduto { get; set; }  //bool false //nome null//

        public double Proco { get; set; } //get busca set altera 
                                         // métado de encapsulamentos realidado e a propriedade
        public int qtde;
        //static o atributo sai da intancia 
        //o metado também precisa ser estatico

        public void  MostarDados()
        {
            Console.WriteLine("Codigo:" + Codigo + "\tQuantidade:" + Qtde + 
            "\tNome: " + NomeProduto);
        }
        public Produto()
        {
            
        }
        public Produto(int c, int q ,string n, double p) //intancia co inicia com new com o costrutor = new Pruduto(); 
                         //o costrutor precisar ter o nome igual da classe
        {
            Proco = p;
            Codigo = c;
            NomeProduto = n;
            qtde = q;

        } //iniciar os atributos do objeto
        public int Qtde  // emcapsulamento
        {
            get { return qtde; } // so usa o atributo,
                                  //pode determinar se e publíco ou privado
            set 
            { 
                if(value > 0)
                 qtde = value; 
                else
                    Console.WriteLine("Quantidade inválida");
                
            } //fazer auteração no conteúdo ou buscar o conteúdo
        }
        
    }
}

