﻿//função Main()implicita
using RevisaoContrutorAgregacao;

Produto p1 =  new Produto(3,6,"tela",600);
Console.WriteLine("Código:" + Produto.Codigo);//
//representa os atributos 
Produto p2 = new Produto(3,1,"mause", 3000);
Produto p3 = new Produto();

Carrinho  c = new Carrinho();

c.Itens = new List<Produto>();
c.Itens.Add(p1); //pegando um produto estanciado
c.Itens.Add(p2);  //acontece a agregação
c.ExibeDados();

