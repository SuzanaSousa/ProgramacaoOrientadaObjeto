using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AbstrataFuncionario
{
    public class Dependente
    {
        public int Codigo { get; set; }

        public string Nome { get; set; }

        public int Idade { get; set; }

        public Dependente(int codigo, string nome, int idade)
        {
            Codigo = codigo;
            Nome = nome;
            Idade = idade;

        }
        public bool VerificarMaiorIdade()
        {
            if (Idade >= 18)  
               return true;

            return false;

        }
        public void MostrarDependente()
        {
            Console.WriteLine("Codigo:" + Codigo + "Nome:" + Nome + "Idade:" + Idade);
        }
        
    }


}
