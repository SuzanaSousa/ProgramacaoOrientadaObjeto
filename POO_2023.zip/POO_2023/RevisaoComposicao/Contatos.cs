using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevisaoComposicao
{
    public class Contatos
    {
        public string Nome { get; set; }

        public string Email { get; set; }

        public  string Telefone { get; set; }

        //estancia os dois objetos ao mesmo tempo

        public Contatos( string nome,string email,string telefone)
        {
            Nome = nome;
            Email = email;
            Telefone = telefone;
        }
        public void ListarContados()
        {
            Console.WriteLine("Nome:" + Nome +  "\tE-mail:" + Email +"\tTelefone:" + Telefone );
        }

      
    }
}             //composição e um tipo de relação entre as classe
              // s mais forte pois acontecem ao mesmo tempo

