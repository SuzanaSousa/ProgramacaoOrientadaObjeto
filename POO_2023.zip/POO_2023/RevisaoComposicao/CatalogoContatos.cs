using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevisaoComposicao
{
    public class CatalogoContatos
    {
        public string Nome { get; set; }

        public List<Contatos> ListaDeContatos { get; set; }

        public CatalogoContatos(string nome,List<Contatos> lista)
        {
            Nome = nome;
            ListaDeContatos = lista;
            //ou ListadeContados = new List<Contatos>();
        }
        public void ExibirContatos()
        {
            foreach(Contatos c in ListaDeContatos)
                     c.ListarContados();
        }

    }
}

