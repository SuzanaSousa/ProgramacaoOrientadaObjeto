﻿//função Main();
//destruir a intancia  
using RevisaoComposicao;

Contatos  c1 = new Contatos("Caio", "caio@gmail","18888");
Contatos  c2= new Contatos("Leo","leo12@","111111");
Contatos  c3 = new Contatos("Max Lanches","ml12@","555");
Contatos  c4 = new Contatos("Big Lanches","bl13@","9999");

List<Contatos> vet1 = new List<Contatos>();
vet1.Add(c1);
vet1.Add(c2);
CatalogoContatos cat1 = new CatalogoContatos("TurmaPOO_Noite", vet1);
Console.WriteLine("-----------\nNome do Catalogo:" + cat1.Nome + "---------------");
cat1.ExibirContatos();

List<Contatos> vet2 = new List<Contatos>();
vet2.Add(c3);
vet2.Add(c4);
CatalogoContatos cat2 = new CatalogoContatos("Lanchonetes", vet2);
Console.WriteLine("-----------\nNome do Catalogo:" + cat2.Nome + "---------------");
cat2.ExibirContatos();

cat1 = null;// retirada da referencia de menoria do objeto
cat2 = null;
GC.Collect();//ch[chamada do coletor de lixo
// as linhas acima são opção do programador

