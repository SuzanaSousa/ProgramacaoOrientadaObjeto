﻿// função Main() implícita
using EncapsulamentoConta;

Conta c1 = new Conta();
c1.Numero = 1;
c1.Titular = "Bob";
c1.Saldo = 100.45M;

Conta c2 = new Conta();
c2.Numero = 0;
c2.Titular = "";
c2.Saldo = -1;
